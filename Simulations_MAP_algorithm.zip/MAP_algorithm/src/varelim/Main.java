package varelim;

import java.util.*;

/**
 * Main class to read in a network and run the MAP-selection problem.
 * 
 * @author Simon Janssen
 */

public class Main {
	private final static String alarmNetworkName = "alarm.bif";
	private final static String earthquakeNetworkName = "earthquake.bif"; // The network to be read in (format and other networks can be found on http://www.bnlearn.com/bnrepository/


	public static void main(String[] args) {
		// Read in the network
		Networkreader reader = new Networkreader(alarmNetworkName);

		// Get the variables and probabilities of the network
		ArrayList<Variable> vs = reader.getVs();
		ArrayList<Table> ps = reader.getPs();

		// Make user interface
		UserInterface ui = new UserInterface(vs, ps);

		// Initialise the out-degrees of the variables, read off from the ALARM network
		Map<String, Integer> out_degree = initialiseOutDegreeALARM();

		// Define MAP-Independence instance
		MAPIndependence map_independence = new MAPIndependence(vs, ps, ui, out_degree);
		// Compute the MAP-selection problem
		map_independence.computeBestVarToObserve();
	}

	private static Map<String, Integer> initialiseOutDegreeALARM() {
		Map<String, Integer> out_degree = new HashMap<>();
		out_degree.put("HISTORY", 0);
		out_degree.put("CVP", 0);
		out_degree.put("PCWP", 0);
		out_degree.put("HYPOVOLEMIA", 2);
		out_degree.put("LVEDVOLUME", 2);
		out_degree.put("LVFAILURE", 3);
		out_degree.put("STROKEVOLUME", 1);
		out_degree.put("ERRLOWOUTPUT", 1);
		out_degree.put("HRBP", 0);
		out_degree.put("HREKG", 0);
		out_degree.put("ERRCAUTER", 2);
		out_degree.put("HRSAT", 0);
		out_degree.put("INSUFFANESTH", 1);
		out_degree.put("ANAPHYLAXIS", 1);
		out_degree.put("TPR", 2);
		out_degree.put("EXPCO2", 0);
		out_degree.put("KINKEDTUBE", 2);
		out_degree.put("MINVOL", 0);
		out_degree.put("FIO2", 1);
		out_degree.put("PVSAT", 1);
		out_degree.put("SAO2", 1);
		out_degree.put("PAP", 0);
		out_degree.put("PULMEMBOLUS", 2);
		out_degree.put("SHUNT", 1);
		out_degree.put("INTUBATION", 5);
		out_degree.put("PRESS", 0);
		out_degree.put("DISCONNECT", 1);
		out_degree.put("MINVOLSET", 1);
		out_degree.put("VENTMACH", 1);
		out_degree.put("VENTTUBE", 2);
		out_degree.put("VENTLUNG", 3);
		out_degree.put("VENTALV", 2);
		out_degree.put("ARTCO2", 2);
		out_degree.put("CATECHOL", 1);
		out_degree.put("HR", 4);
		out_degree.put("CO", 1);
		out_degree.put("BP", 0);
		return out_degree;
	}
}