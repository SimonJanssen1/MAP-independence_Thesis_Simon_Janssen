package varelim;

import java.util.*;

/**
 * Class that computes (Maximum Weak) MAP-independence in Bayesian network relative to a hypothesis set.
 *
 * @author Merlijn van Elteren, Luuk Jacobs & Simon Janssen
 * Extended by Simon Janssen
 */

public class MAPIndependence {
    // General for a network
    private final ArrayList<Table> tables;
    private final ArrayList<Variable> variables;
    private final UserInterface ui;
    private final VariableElimination algorithm;
    private final Map<String, Integer> out_degree;

    // Specific for computation MAP-independence
    private ArrayList<Variable> evidence = new ArrayList<>();
    private ArrayList<Variable> hypotheses = new ArrayList<>();
    private ArrayList<Variable> intermediates;
    private ArrayList<Factor> factors;
    private String heuristic;

    /**
     * Constructor MAPIndependence class.
     *
     * @param variables   : all variables in the network
     * @param tables      : all probability tables in the network
     * @param ui          : User interface
     * @param out_degree  : out-degree of all variables in the network
     */
    public MAPIndependence(ArrayList<Variable> variables, ArrayList<Table> tables, UserInterface ui, Map<String, Integer> out_degree) {
        this.variables = variables;
        this.tables = tables;
        this.ui = ui;
        this.algorithm = VariableElimination.getInstance();
        this.out_degree = out_degree;
    }

    /**
     * This function instantiates the MAP-independence class. In this function, hypotheses, evidence and a heuristic
     * is requested from the user.
     */
    private void instantiate() {
        this.intermediates = getCopy(this.variables);
        // Erase data from previous call
        for (Variable var : intermediates) {
            var.setObserved(false);
            var.setObservedValue(null);
            var.setBestValue(null);
        }

        // Initialise Random to draw random hypothesis and evidence variables
        Random random = new Random();

        // Split variables off into random hypothesis variable and remaining:
        int idx = random.nextInt(this.intermediates.size());
        Variable hyp = this.intermediates.remove(idx);
        this.hypotheses.add(hyp);

        //Split remaining variables off into random evidence set and remaining:
        int evidence = 0;
        for(int i = 1; i <= evidence; i++){
            // Draw random variable
            idx = random.nextInt(this.intermediates.size());
            Variable evi = this.intermediates.remove(idx);
            // Draw random value for variable
            idx = random.nextInt(evi.getNrOfValues());
            // Set evidence and add to set
            evi.setObserved(true);
            evi.setObservedValue(evi.getValues().get(idx));
            this.evidence.add(evi);
        }

        // Print query and observed variables
        ui.printQueryAndObserved(this.hypotheses, this.evidence);

        // Set heuristic
        this.heuristic = "fewest-factors";

        // Create an array of factors
        this.factors = new ArrayList<>();
        for (Table t : this.tables) {
            factors.add(new Factor(t.getVariable(), t.getTableCopy()));
        }
    }

    /**
     * This function computes which intermediate variable has the largest expected size of the set of
     * MAP-independent variables in the resulting Bayesian network, when observed.
     *
     * @return variable(s) of which the observation leads to the largest expected size of the set MAP-independent variables
     */
    public Set<Variable> computeBestVarToObserve() {
        // Define the MAP problem
        instantiate();
        // Compute the maximal set of MAP-independent variables
        ArrayList<Variable> independent = computeMaxWeakMAPIndependenceWithHeuristic(getFactorCopy(this.factors), getCopy(this.evidence), getCopy(this.intermediates));
        // Get the list of MAP-dependent variables
        ArrayList<Variable> dependent = getCopy(this.intermediates);
        dependent.removeAll(independent);
        // Initialise new arrays for updated evidence and intermediate variables
        ArrayList<Variable> addedEvidence = getCopy(this.evidence);
        ArrayList<Variable> newIntermediates = getCopy(this.intermediates);
        // Keep track of best variable to observe
        Set<Variable> best = new HashSet<>();
        double maximalIndependent = independent.size();
        // Iterate through the MAP-dependent variables and values for those variables
        for (Variable dep : dependent) {
            System.out.println("\nCheck for var: " + dep.getName());
            dep.setObserved(true);
            addedEvidence.add(dep);
            newIntermediates.remove(dep);
            double expectedSize = 0;
            for (String val : dep.getValues()) {
                // Add the variable to the evidence and remove it from the intermediate variables
                dep.setObservedValue(val);
                // Compute the maximal set of MAP-independent variables again
                ArrayList<Variable> result = computeMaxWeakMAPIndependenceWithoutHeuristic(getFactorCopy(this.factors), addedEvidence, newIntermediates);
                System.out.println("Size when " + dep.getName() + " takes on value " + val + ": " + result.size() + ", " + result.toString());
                double prob = findProbForAssignment(dep.getPosterior(), val);
                // Compute p(val | e) * MaxWeakMAP-Indep(B_val,new)
                expectedSize += (prob * result.size());
                // Reset the evidence and intermediate set
                dep.setObservedValue(null);
            }
            System.out.println("Expected size: " + expectedSize);
            // Check whether the resulting set is bigger than the current maximum
            if (expectedSize > maximalIndependent) {
                maximalIndependent = expectedSize;
                best = new HashSet<>();
                best.add(dep);
            } else if (expectedSize == maximalIndependent) {
                best.add(dep);
            }
            dep.setObserved(false);
            addedEvidence.remove(dep);
            newIntermediates.add(dep);
        }
        System.out.println("The best variable(s) to observe is/are: " + best);
        return best;
    }

    /**
     * This function computes the maximum set of weak MAP-independent variables by iteratively computing MAP-independence
     * for a set R containing only one of the intermediate variables.
     *
     * @param factors
     * @param evidence
     * @param intermediates
     * @return maximal set of weak MAP-independent variables
     */
    public ArrayList<Variable> computeMaxWeakMAPIndependenceWithoutHeuristic(ArrayList<Factor> factors, ArrayList<Variable> evidence, ArrayList<Variable> intermediates) {
        algorithm.reduceObservedVariables(factors, evidence);
        //Solve MAP once without setting any intermediate variables to specific values to find the optimal value-assignment h*.
        ArrayList<String> h_star = algorithm.solveMAP(getFactorCopy(factors), new ArrayList<>(), getCopy(intermediates), getCopy(this.hypotheses), this.heuristic);
        // Initialise ArrayLists:
        ArrayList<Variable> maxSet = new ArrayList<>();
        ArrayList<Variable> intermediate;
        ArrayList<Variable> R = new ArrayList<>();
        outerloop:
        for (Variable var : intermediates) {
            // Compute weak MAP-independence for variable var.
            intermediate = getCopy(this.intermediates);
            intermediate.remove(var);
            var.setObserved(true);
            // Go through all possible value assignments to see whether best assignment changes or not
            for (String assignment : var.getValues()) {
                // Make the variables observed and set the value to the value in the assignment
                var.setObservedValue(assignment);
                R.add(var);
                // Solve MAP when the variables from set R are added to the evidence set with the specific value assignment
                ArrayList<String> hAssignment = algorithm.solveMAP(getFactorCopy(factors), getCopy(R), getCopy(intermediate), getCopy(this.hypotheses), this.heuristic);
                // If the value assignment is not the same as h*, then the set is not MAP-independent.
                R.remove(var);
                if (!equals(h_star, hAssignment)) {
                    continue outerloop;
                }
            }
            // Add variable to the list if independent:
            maxSet.add(var);
            reset();
        }
        return maxSet;
    }

    /**
     * This function computes the maximum set of weak MAP-independent variables by iteratively computing MAP-independence
     * for a set R containing only one of the intermediate variables.
     *
     * @param factors
     * @param evidence
     * @param intermediates
     * @return maximal set of weak MAP-independent variables
     */
    public ArrayList<Variable> computeMaxWeakMAPIndependenceWithHeuristic(ArrayList<Factor> factors, ArrayList<Variable> evidence, ArrayList<Variable> intermediates) {
        algorithm.reduceObservedVariables(factors, evidence);
        //Solve MAP once without setting any intermediate variables to specific values to find the optimal value-assignment h*.
        ArrayList<String> h_star = algorithm.solveMAP(getFactorCopy(factors), new ArrayList<>(), getCopy(intermediates), getCopy(this.hypotheses), this.heuristic);
        System.out.println("Assignment without additional evidence: " + this.hypotheses.get(0).getPosterior() + "\n");
        // Initialise ArrayLists:
        ArrayList<ProbRow> posteriorHyp = this.hypotheses.get(0).getPosterior();
        ArrayList<Variable> maxSet = new ArrayList<>();
        ArrayList<Variable> intermediate;
        ArrayList<Variable> newIntermediates;
        ArrayList<Variable> newHypotheses;
        ArrayList<Variable> R = new ArrayList<>();
        for (Variable var : intermediates) {
            // Update list of intermediate variables.
            newIntermediates = getCopy(this.intermediates);
            newIntermediates.remove(var);
            newIntermediates.addAll(getCopy(this.hypotheses));
            // Compute posterior probability of observing var, given the evidence (Pr(var | e)).
            newHypotheses = new ArrayList<>();
            newHypotheses.add(var);
            ArrayList<ProbRow> posterior_var_given_e = algorithm.solve(getFactorCopy(factors), new ArrayList<>(), getCopy(newIntermediates), newHypotheses, this.heuristic);
            var.setPosterior(posterior_var_given_e);

            // Compute weak MAP-independence for variable var.
            intermediate = getCopy(this.intermediates);
            intermediate.remove(var);
            var.setObserved(true);
            boolean independent = true;
            // Initialise values for heuristics:
            double lin_val_utility = 0;
            double ginis = 0;
            double cond_entropies = 0;
            // Go through all possible value assignments to see whether best assignment changes or not
            for (String assignment : var.getValues()) {
                // Make the variables observed and set the value to the value in the assignment
                var.setObservedValue(assignment);
                R.add(var);
                // Solve MAP when the variables from set R are added to the evidence set with the specific value assignment
                ArrayList<String> hAssignment = algorithm.solveMAP(getFactorCopy(factors), getCopy(R), getCopy(intermediate), getCopy(this.hypotheses), this.heuristic);
                // If the value assignment is not the same as h*, then the set is not MAP-independent.
                if (!equals(h_star, hAssignment)) {
                    independent = false;
                }
                R.remove(var);
                // Compute heuristics:
                double probAss = findProbForAssignment(posterior_var_given_e, assignment);
                ArrayList<ProbRow> newPosteriorHyp = this.hypotheses.get(0).getPosterior();
                lin_val_utility += (computeLinValUtility(h_star.get(0), posteriorHyp, newPosteriorHyp) * probAss);
                ginis += (computeGiniIndex(newPosteriorHyp) * probAss);
                cond_entropies += (computeEntropy(newPosteriorHyp) * probAss);
                System.out.println("Assignment for variable " + var.getName() + " taking on value " + assignment + ": " + newPosteriorHyp);
            }
            // Add variable to the list if independent:
            if (independent) {
                maxSet.add(var);
            } else {
                // Compute and show heuristics:
                double gini_hyp = computeGiniIndex(posteriorHyp);
                double expected_gini = gini_hyp - ginis;
                double mut_inf_hyp = computeEntropy(posteriorHyp);
                double mutual_information = mut_inf_hyp - cond_entropies;
                ui.showHeuristics(var, lin_val_utility, expected_gini, mutual_information, var.getNrOfParents(), this.out_degree.get(var.getName()), "dist");
            }
            reset();
        }
        System.out.println(maxSet);
        System.out.println("Size: " + maxSet.size());
        return maxSet;
    }

    /**
     * Compute the entropy over the posterior distribution of a hypothesis variable
     *
     * @param table: posterior distribution
     * @return entropy
     */
    private double computeEntropy(ArrayList<ProbRow> table) {
        double result = 0;
        for (ProbRow row : table) {
            result -= (row.getProb() * (Math.log(row.getProb()) / Math.log(2.0)));
        }
        return result;
    }

    /**
     * Compute the gini index over the posterior distribution of a hypothesis variable
     *
     * @param table: posterior distribution
     * @return gini index
     */
    private double computeGiniIndex(ArrayList<ProbRow> table) {
        double result = 0;
        for (ProbRow row : table) {
            result += Math.pow(row.getProb(), 2.0);
        }
        return 1 - result;
    }

    /**
     * Compute the linear-value utility function as expressed in the paper of Van der Gaag and Wessels (1993).
     *
     * @param h:               value assignment of hypothesis
     * @param posteriorHyp:    posterior distribution of hypothesis, given the evidence.
     * @param newPosteriorHyp: posterior distribution of hypothesis, given evidence and value for variable.
     * @return result of computing the linear-value utility function
     */
    private double computeLinValUtility(String h, ArrayList<ProbRow> posteriorHyp, ArrayList<ProbRow> newPosteriorHyp) {
        double pr_h = findProbForAssignment(posteriorHyp, h);
        double pr_h_v = findProbForAssignment(newPosteriorHyp, h);
        return Math.abs(pr_h - pr_h_v);
    }

    /**
     * This function searches the probability in a probability table for a given value assignment of a variable that is
     * contained within the table.
     *
     * @param table:      probability table
     * @param assignment: value assignment of the variable contained in the table.
     * @return probability of value assignment for the variable.
     */
    private double findProbForAssignment(ArrayList<ProbRow> table, String assignment) {
        for (ProbRow row : table) {
            if (row.getValues().contains(assignment)) {
                return row.getProb();
            }
        }
        return -1.0;
    }

    /**
     * This function computes MAP-independence for a given set of variables.
     *
     * @param R : variable to compute MAP-independence for.
     * @return boolean indicating whether or not the set is MAP-independent from the hypotheses.
     */
    public boolean computeMAPIndependence(ArrayList<Factor> factors, ArrayList<Variable> R, ArrayList<String> h_star) {
        ArrayList<Variable> intermediate = getCopy(this.intermediates);
        intermediate.removeAll(R);
        // Compute all possible combined value assignments for set R:
        List<List<String>> assignments = computePossibleAssignments(getCopy(R), new ArrayList<>(), new ArrayList<>());
        // Iterate through the value assignments for the variables in set R:
        boolean isMAPIndependent = true;
        for (List<String> assignment : assignments) {
            // Make the variables observed and set the value to the value in the assignment
            for (int i = 0; i < R.size(); i++) {
                Variable var = R.get(i);
                var.setObserved(true);
                var.setObservedValue(assignment.get(i));
            }
            System.out.println("Assignment for set " + R.toString() + " taking on values " + assignment);
            // Solve MAP when the variables from set R are added to the evidence set with the specific value assignment
            List<String> hAssignment = algorithm.solveMAP(getFactorCopy(factors), getCopy(R), getCopy(intermediate), getCopy(this.hypotheses), this.heuristic);
            // If the value assignment is not the same as h*, then the set is not MAP-independent.
            if (!equals(h_star, hAssignment)) {
                isMAPIndependent = false;
            }
        }
        // If all value assignments result in the same assignment h* for the hypotheses, the set R is MAP-independent.
        return isMAPIndependent;
    }

    /**
     * Set intermediate variables back to unobserved and without an observed or best value.
     */
    private void reset() {
        for (Variable var : intermediates) {
            var.setObserved(false);
            var.setObservedValue(null);
            var.setBestValue(null);
        }
    }

    /**
     * This function computes whether two value assignments, represented as a list of Strings, are equal.
     *
     * @param h1: value assignment 1
     * @param h2: value assignment 2
     * @return boolean indicating whether two assignments are equal or not
     */
    private boolean equals(List<String> h1, List<String> h2) {
        if (h1.size() != h2.size()) {
            System.err.println("THESE ASSIGNMENTS ARE NOT OF EQUAL SIZE");
            return false;
        }
        for (int i = 0; i < h1.size(); i++) {
            if (!h1.get(i).equals(h2.get(i))) {
                return false;
            }
        }
        return true;
    }

    /**
     * This function computes all possible value assignments for a given set of variables.
     *
     * @param R          : set of variables for which to compute all possible value assignments
     * @param result     : resulting list of value assignments
     * @param assignment : initial value assignment (empty list)
     * @return an ArrayList of all possible value assignments for a given list of variables.
     */
    private List<List<String>> computePossibleAssignments(List<Variable> R, List<List<String>> result, List<String> assignment) {
        Variable v = R.remove(0);
        // Add every possible value to the current assignment
        for (String value : v.getValues()) {
            assignment.add(value);
            List<String> copy = new ArrayList<>(assignment);
            // If this was the last variable for which a value is required, then add it to the list of results
            if (R.isEmpty()) {
                result.add(copy);
                // Else, add recurse with the value added to the assignment and add for the remaining variables a value to the assignment.
            } else {
                List<Variable> vars = new ArrayList<>(R);
                computePossibleAssignments(vars, result, copy);
            }
            // Reset the assignment so the next value for variable v can be added.
            assignment.remove(assignment.size() - 1);
        }
        return result;
    }

    /**
     * This function returns a shallow copy of a given list.
     *
     * @param list
     * @return shallow copy of provided list
     */
    private ArrayList<Variable> getCopy(ArrayList<Variable> list) {
        return new ArrayList<>(list);
    }

    /**
     * This function returns a copy of a list of factors
     *
     * @return new duplicate list of factors
     */
    public static ArrayList<Factor> getFactorCopy(ArrayList<Factor> factors) {
        ArrayList<Factor> result = new ArrayList<>();
        for (Factor f : factors) {
            result.add(new Factor(f));
        }
        return result;
    }

}
