package varelim;

import java.util.*;

/**
 * Class where the variable elimination algorithm is executed, either for a MAP problem or to compute the
 * posterior probability over a variable
 *
 * @author Simon Janssen and Jonathan Bauermeister
 */

public class VariableElimination {
    private static final VariableElimination instance = null;

    /**
     * Constructor of the class
     */
    private VariableElimination() {
    }

    /**
     * Singleton instance creator.
     *
     * @return instance of the class.
     */
    public static VariableElimination getInstance(){
        if(instance == null){
            synchronized (VariableElimination.class){
                if(instance == null){
                    return new VariableElimination();
                }
            }
        }
        return instance;
    }

    /**
     * This function starts the variable elimination procedure to compute a posterior probability over the variables of
     * interest (hypotheses).
     *
     * @param heuristic, chosen heuristic as a string
     */
    public ArrayList<ProbRow> solve(ArrayList<Factor> factors, ArrayList<Variable> observed, ArrayList<Variable> intermediate, ArrayList<Variable> hypotheses, String heuristic) {
        if(!observed.isEmpty()) {
            reduceObservedVariables(factors, observed);
        }
        Heuristic h = new Heuristic(heuristic);
        ArrayList<Variable> order = h.apply(intermediate, factors);
        // Eliminate the variables one by one, except the queried variable.
        for (Variable varToMarginalize : order) {
            eliminateVariable(varToMarginalize, factors);
            intermediate.remove(varToMarginalize);
        }
        // If there is more than one factor containing the queried variable, multiply them to get one final factor.
        while (factors.size() > 1) {
            Factor f1 = factors.remove(0);
            Factor f2 = factors.remove(0);
            factors.add(f1.product(f2));
        }
        // Normalize the result to get a probability distribution for the queried variable.
        factors.get(0).normalize();
        return factors.get(0).getTable();
    }

    /**
     * This function starts the variable elimination procedure to compute the joint value assignment over the variables
     * of interest (hypotheses).
     *
     * @param heuristic, chosen heuristic as a string.
     */
    public ArrayList<String> solveMAP(ArrayList<Factor> factors, ArrayList<Variable> observed, ArrayList<Variable> intermediate, ArrayList<Variable> hypotheses, String heuristic) {
        if(!observed.isEmpty()) {
            reduceObservedVariables(factors, observed);
        }
        Heuristic h = new Heuristic(heuristic);
        ArrayList<Variable> order = h.apply(intermediate, factors);
        // Eliminate the variables one by one, except the queried variable.
        for (Variable varToMarginalize : order) {
            eliminateVariable(varToMarginalize, factors);
            intermediate.remove(varToMarginalize);
        }
        // Fix maximization ordering
        Heuristic h2 = new Heuristic("fewest-factors");
        ArrayList<Variable> maxOrdering = h2.apply(hypotheses, factors);
        // Compute the best value for every hypothesis variable.
        maximizeVariables(maxOrdering, factors);
        // Print the best value for every hypothesis variable.
        ArrayList<String> results = new ArrayList<>();
        for (Variable hyp : hypotheses) {
            results.add(hyp.getBestValue());
        }
        return results;
    }

    /**
     * This function computes the best value for each variable. It does so by applying the argmax operation on the
     * factors containing the hypothesis variables.
     *
     * @param ordering
     * @param factors
     */
    public void maximizeVariables(ArrayList<Variable> ordering, ArrayList<Factor> factors) {
        // Check if there are multiple hypothesis variables.
        if (ordering.size() > 1) {
            Variable var = ordering.remove(0);
            // Add factors containing variable to a new arraylist and remove them from the original list.
            ArrayList<Factor> containVar = containedIn(var, factors);
            // Multiply the factors that contain the variable until there is only one factor left.
            Factor result = computeProduct(containVar, true);
            // Maximize over the resulting factor and add it to the factors list.
            result = result.maximize(var);
            factors.add(result);
            // Make a duplicate of the current ordering.
            ArrayList<Variable> myOrdering = new ArrayList<>(ordering);
            // Recurse to get the assignments of the next variables in the ordering.
            maximizeVariables(ordering, factors);
            // Reduce the factors to the values of the other variables later in the ordering.
            for (Variable hyp : myOrdering) {
                for (Factor f : containVar) {
                    if (f.containsVar(hyp)) {
                        f.reduce(hyp, hyp.getBestValue());
                    }
                }
            }
            // Multiply the reduced factors.
            Factor res = computeProduct(containVar, false);
            // Do an argmax on the resulting factor
            String bestValue = res.argmax();
            var.setBestValue(bestValue);
            // Return.
        } else if (ordering.size() == 1) {
            Factor result = computeProduct(factors, false);
            Factor normalized = result.normalize();
            ordering.get(0).setPosterior(normalized.getTable());
            // Do an argmax on the resulting factor
            String bestValue = normalized.argmax();
            ordering.get(0).setBestValue(bestValue);
            // If you have an empty factor, return.
        } else {
            System.err.println("No hypothesis variables! Something went wrong.");
        }
    }

    /**
     * This function reduces observed variables of all factors containing such a variable, by calling the reduce function
     * on a factor with the given observed variable and value.
     */
    public void reduceObservedVariables(List<Factor> factors, List<Variable> observed) {
        // Iterate through the list of observed variables.
        if (!observed.isEmpty()) {
            for (Variable var : observed) {
                Iterator<Factor> it = factors.iterator();
                while (it.hasNext()) {
                    Factor factor = it.next();
                    if (factor.containsVar(var)) {
                        //If the factor only has the variable we want to reduce it will result in a factor with an empty table,
                        // which is not useful, so we remove the empty factor.
                        if (factor.NrOfVariables() == 1) {
                            it.remove();
                        } else {
                            factor.reduce(var, var.getObservedValue());
                        }
                    }
                }
            }
        }
    }

    /**
     * This function eliminates a given variable from all the factors containing it. First it checks which factors contain the variable.
     * If more than two factors contain the variable they will be multiplied together according to the multiply function in Factor.
     * Lastly the variable will be marginalized and therefore eliminated. If the resulting factors still contains variables, it
     * will be added to the factors list again as a new factor.
     *
     * @param var, variable to eliminate
     */
    public void eliminateVariable(Variable var, ArrayList<Factor> factors) {
        // Check in which factors the variable is contained and add those to a new list.
        ArrayList<Factor> containVar = containedIn(var, factors);
        if (!containVar.isEmpty()) {
            // Multiply the factors that contain the variable until there is only one factor left.
            Factor res = computeProduct(containVar, false);
            // Marginalize out the variable from the factor and add it to the list if the factor still contains variables.
            Factor result = res.marginalize(var);
            if (result.NrOfVariables() > 0) {
                factors.add(result);
            }
        }
    }

    /**
     * This function checks in which factors the variable is contained. It adds those to a new list, and removes them
     * from the list given in the input.
     *
     * @param v
     * @param factors
     * @return an ArrayList of factors in which variable v is contained.
     */
    private ArrayList<Factor> containedIn(Variable v, ArrayList<Factor> factors) {
        ArrayList<Factor> containVar = new ArrayList<>();
        Iterator<Factor> it = factors.iterator();
        // Check in which factors the variable is contained and add those to a new list.
        while (it.hasNext()) {
            Factor factor = it.next();
            if (factor.containsVar(v)) {
                containVar.add(factor);
                it.remove();
            }
        }
        return containVar;
    }

    /**
     * This function computes the product in a list of factors.
     *
     * @param factors
     * @param preserve, determines whether or not to preserve the original factor list.
     * @return result of taking a product between a list of factors.
     */
    private Factor computeProduct(ArrayList<Factor> factors, boolean preserve) {
        // If the original factors need to be preserved:
        if (preserve) {
            // Create a new copy of the first factor
            Factor result = new Factor(factors.get(0));
            int i = 1;
            // While there are other factors, do the product between the result and the factor
            while (factors.size() > i) {
                Factor fac = factors.get(i);
                result = result.product(fac);
                i++;
            }
            // Return the result.
            return result;
            // If the original factors do not need to be preserved:
        } else {
            // Compute the product between two factors and put back the resulting factor in the list.
            while (factors.size() > 1) {
                Factor f1 = factors.remove(0);
                Factor f2 = factors.remove(0);
                factors.add(f1.product(f2));
            }
            // If there is only one factor left, this is the result which can be returned.
            return factors.get(0);
        }
    }
}


