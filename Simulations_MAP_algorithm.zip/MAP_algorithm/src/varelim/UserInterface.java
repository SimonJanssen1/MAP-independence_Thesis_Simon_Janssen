package varelim;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * Class that handles the communication with the user.
 *
 * @author Marcel de Korte, Moira Berens, Djamari Oetringer, Abdullahi Ali, Leonieke van den Bulk
 * Adapted by Merlijn van Elteren, Luuk Jacobs and Simon Janssen
 */

public class UserInterface {

    private ArrayList<Variable> vs;
    final ArrayList<Table> ps;
    ArrayList<Factor> fs;
    private final ArrayList<Variable> hypotheses = new ArrayList<>();
    private final ArrayList<Variable> evidence = new ArrayList<Variable>();
    private String line;
    private String heuristic;
    private Scanner scan;

    /**
     * Constructor of the user interface.
     *
     * @param vs, the list of variables.
     * @param ps, the list of probability tables.
     */
    public UserInterface(ArrayList<Variable> vs, ArrayList<Table> ps) {
        this.vs = vs;
        this.ps = ps;
    }

    /**
     * Setter of the factors that are displayed in the user interface
     *
     * @param newFs
     */
    public void setFs(ArrayList<Factor> newFs) {
        this.fs = newFs;
    }

    /**
     * Setter of the variables that are displayed in the user interface
     *
     * @param newVs
     */
    public void setVs(ArrayList<Variable> newVs) {
        this.vs = newVs;
    }

    /**
     * Asks for queries from the user.
     */
    public void askForHypotheses() {
        hypotheses.clear();
        System.out.println("Which variable(s) do you want to query? Please enter in the number of the variable." +
                " Do not use spaces. \n"
                + "If you want to query multiple variables, delimit them with a ';' and no spaces.\n"
                + "Example: '2;3'");
        for (int i = 0; i < vs.size(); i++) {
            System.out.println("Variable " + i + ": " + vs.get(i).getName());
        }
        scan = new Scanner(System.in);
        line = scan.nextLine();
        if (line.isEmpty()) {
            System.out.println("You have not chosen a query value. Please choose a query value.");
            askForHypotheses();
        } else {
            while (line.contains(";")) { // Multiple observed variables
                try {
                    int queriedVar = Integer.parseInt(line.substring(0, line.indexOf(";")));
                    if (queriedVar >= 0 && queriedVar < vs.size()) {
                        hypotheses.add(vs.get(queriedVar));
                    } else {
                        System.out.println(queriedVar + " is not a correct index. Please choose an index between " + 0 + " and "
                                + (vs.size() - 1) + ".");
                        askForHypotheses();
                    }
                    line = line.substring(line.indexOf(";") + 1); // Continue with next observed variable.
                } catch (NumberFormatException ex) {
                    System.out.println("This is not a correct input. Please choose an index between " + 0 + " and "
                            + (vs.size() - 1) + ".");
                    askForHypotheses();
                    return;
                }
            }
            if (!line.contains(";")) { // Only one observed variable
                try {
                    int queriedVar = Integer.parseInt(line);
                    if (queriedVar >= 0 && queriedVar < vs.size()) {
                        hypotheses.add(vs.get(queriedVar));
                    } else {
                        System.out.println(queriedVar + " is not a correct index. Please choose an index between " + 0 + " and "
                                + (vs.size() - 1) + ".");
                        askForHypotheses();
                    }
                } catch (NumberFormatException ex) {
                    System.out.println("This is not a correct input. Please choose an index between " + 0 + " and "
                            + (vs.size() - 1) + ".");
                    askForHypotheses();
                }
            }
        }
    }

    /**
     * Ask the user for observed variables in the network.
     */
    public void askForEvidenceVariables() {

        evidence.clear();
        System.out.println("Which variable(s) do you want to observe? Please enter in the number of the variable, \n"
                + "followed by a comma and the value of the observed variable. Do not use spaces. \n"
                + "If you want to query multiple variables, delimit them with a ';' and no spaces.\n"
                + "Example: '2,True;3,False'");
        for (int i = 0; i < vs.size(); i++) {
            String values = "";
            for (int j = 0; j < vs.get(i).getNrOfValues() - 1; j++) {
                values = values + vs.get(i).getValues().get(j) + ", ";
            }
            values = values + vs.get(i).getValues().get(vs.get(i).getNrOfValues() - 1);

            System.out.println("Variable " + i + ": " + vs.get(i).getName() + " - " + values);
        }
        scan = new Scanner(System.in);
        line = scan.nextLine();
        if (line.isEmpty()) {
        } else {
            if (!line.contains(",")) {
                System.out.println("You did not enter a comma between values. Please try again");
                askForEvidenceVariables();
                return;
            } else {
                while (line.contains(";")) { // Multiple observed variables
                    try {
                        int queriedVar = Integer.parseInt(line.substring(0, line.indexOf(",")));
                        String bool = line.substring(line.indexOf(",") + 1, line.indexOf(";"));
                        changeVariableToEvidence(queriedVar, bool);
                        line = line.substring(line.indexOf(";") + 1); // Continue
                        // with
                        // next
                        // observed
                        // variable.
                    } catch (NumberFormatException ex) {
                        System.out.println("This is not a correct input. Please choose an index between " + 0 + " and "
                                + (vs.size() - 1) + ".");
                        askForEvidenceVariables();
                        return;
                    }
                }
                if (!line.contains(";")) { // Only one observed variable
                    try {

                        int queriedVar = Integer.parseInt(line.substring(0, line.indexOf(",")));
                        String bool = line.substring(line.indexOf(",") + 1);
                        changeVariableToEvidence(queriedVar, bool);
                    } catch (NumberFormatException ex) {
                        System.out.println("This is not a correct input. Please choose an index between " + 0 + " and "
                                + (vs.size() - 1) + ".");
                        askForEvidenceVariables();
                    }
                }
            }
        }
    }

    /**
     * Checks whether a number and value represent a valid observed value or not and if so, adds it to the
     * observed list. If not, asks again for new input.
     */
    public void changeVariableToEvidence(int queriedVar, String value) {
        Variable ob;
        if (queriedVar >= 0 && queriedVar < vs.size()) {
            ob = vs.get(queriedVar);
            if (ob.isValueOf(value)) {
                ob.setObservedValue(value);
                ob.setObserved(true);
            } else {
                System.out.println("Apparently you did not fill in the value correctly. You typed: \"" + value
                        + "\"Please try again");
                askForEvidenceVariables();
                return;
            }
            evidence.add(ob); // Adding observed variable and it's value to list.
        } else {
            System.out.println("You have chosen an incorrect index. Please choose an index between " + 0 + " and "
                    + (vs.size() - 1));
            askForEvidenceVariables();
        }
    }

    /**
     * Print the probability tables of the factors that are in the network (by printing the variable and associated table)
     */
    public String printFactors(ArrayList<Factor> fs) {
        String result = "";
        for (int i = 0; i < fs.size(); i++) {
            //Print the factors variable names
            result += fs.get(i).shortString();
            System.out.println(fs.get(i).shortString());

            // Get the factor and print all probability rows for the table of that factor.
            Factor probs = fs.get(i);
            for (int l = 0; l < probs.size(); l++) {
                result += "\n" + probs.get(l);
                System.out.println(probs.get(l));            // Printing
            }
            result += "\n\n";                                 // the
            System.out.println();                            // probabilities.
        }
        return result;
    }

    /**
     * @return String of formula for factors in the network.
     */
    public String printFormula() {
        String result = "";
        for (int i = 0; i < fs.size(); i++) {
            result = result + fs.get(i).shortString() + " ";
        }
        System.out.println(result);
        return result;
    }

    /**
     * Print the network that was read-in (by printing the variables, parents and probabilities).
     *
     * @param The list of variables.
     * @param The list of probabilities.
     */
    public void printNetwork() {
        System.out.println("The variables:");
        for (int i = 0; i < vs.size(); i++) {
            String values = "";
            for (int j = 0; j < vs.get(i).getNrOfValues() - 1; j++) {
                values = values + vs.get(i).getValues().get(j) + ", ";
            }
            values = values + vs.get(i).getValues().get(vs.get(i).getNrOfValues() - 1);
            System.out.println((i + 1) + ") " + vs.get(i).getName() + " - " + values); // Printing
            // the
            // variables.
        }
        System.out.println("\nThe probabilities:");
        for (int i = 0; i < ps.size(); i++) {
            if (vs.get(i).getNrOfParents() == 1) {
                System.out.println(ps.get(i).getVariable().getName() + " has parent "
                        + vs.get(i).getParents().get(0).getName());
            } else if (vs.get(i).getNrOfParents() > 1) {
                String parentsList = "";
                for (int j = 0; j < vs.get(i).getParents().size(); j++) {
                    parentsList = parentsList + vs.get(i).getParents().get(j).getName();
                    if (!(j == vs.get(i).getParents().size() - 1)) {
                        parentsList = parentsList + " and ";
                    }
                }
                System.out.println(ps.get(i).getVariable().getName() + " has parents "
                        + parentsList);
            } else {
                System.out.println(ps.get(i).getVariable().getName() + " has no parents.");
            }

            Table probs = ps.get(i);
            for (int l = 0; l < probs.size(); l++) {
                System.out.println(probs.get(l));            // Printing
            }                                                // the
            System.out.println();                            // probabilities.
        }
    }

    /**
     * Prints the query and observed variables given in by the user.
     *
     * @param The query variable(s).
     * @param The observed variable(s).
     */
    public void printQueryAndObserved(ArrayList<Variable> queries, ArrayList<Variable> Obs) {
        System.out.println("\nThe queried variable(s) is/are: "); // Printing the queried variables.
        for(Variable query : queries) {
            System.out.print(query.getName());
        }
        if (!Obs.isEmpty()) {
            System.out.println("\nThe observed variable(s) is/are: "); // Printing
            // the
            // observed
            // variables.
            for (int m = 0; m < Obs.size(); m++) {
                System.out.println(Obs.get(m).getName() + " with value: " + Obs.get(m).getObservedValue());
            }
        }
    }

    /**
     * Asks for a heuristic.
     */
    public void askForHeuristic() {
        System.out.println("Supply a heuristic. Input 1 for least-incoming, 2 for fewest-factors and enter for random");
        scan = new Scanner(System.in);
        line = scan.nextLine();
        if (line.isEmpty()) {
            heuristic = "empty";
            //System.out.println("You have chosen for the random heuristic");
        } else if (line.equals("1")) {
            heuristic = "least-incoming";
            //System.out.println("You have chosen for the least-incoming heuristic");
        } else if (line.equals("2")) {
            heuristic = "fewest-factors";
            //System.out.println("You have chosen for the fewest-factors heuristic");
        } else {
            System.out.println(line + " is not an option. Please try again");
            askForHeuristic();
        }
    }

    /**
     * This function shows the values for the heuristic that were computed for a variable during Maximum Weak MAP-independence.
     * @param exp_utility: expected utility for linear-value utility function
     * @param expected_gini: expected Gini index
     * @param mutual_information: mutual information
     */
    public void showHeuristics(Variable var, double exp_utility, double expected_gini, double mutual_information, int inDegree, int outDegree, String distance) {
        System.out.println("\nValues for the heuristics for observing variable " + var.getName() + ":");
        System.out.println(var.getName() + ", " + inDegree + ", " + outDegree + ", " + (inDegree + outDegree) + ", " + distance + ", " + exp_utility + ", " + expected_gini + ", " + mutual_information);
        System.out.println();
    }

    /**
     * Getter of the observed variables.
     *
     * @return a list of observed variables given by the user.
     */
    public ArrayList<Variable> getEvidenceVariables() {
        return evidence;
    }

    /**
     * Getter of the queried variables.
     *
     * @return the variable the user wants to query.
     */
    public ArrayList<Variable> getHypothesesVariables() {
        return hypotheses;
    }

    /**
     * Getter of the heuristic.
     *
     * @return the name of the heuristic.
     */
    public String getHeuristic() {
        return heuristic;
    }
}
