package varelim;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Class that orders the variables in a list according to the least-incoming-arcs or contained-in-fewest-factors heuristic
 *
 * @author Simon Janssen and Jonathan Bauermeister
 */

public class Heuristic {

    private final String heuristic;

    /**
     * Constructor of the class.
     * @param heuristic, heuristic that has to be applied
     */
    public Heuristic(String heuristic){
        this.heuristic = heuristic;
    }

    /**
     * This function applies the given heuristic to the variable list in order to order them. If the heuristic was
     * contained-in-fewest-factors, the function will return the result of that particular function. In all other cases,
     * the function will return the heuristic least-incoming-arcs.
     * @param variables
     * @param factors
     * @return updated list of variables: ordering based on heuristic
     */
    public ArrayList<Variable> apply(ArrayList<Variable> variables, ArrayList<Factor> factors){
        if ("fewest-factors".equals(this.heuristic)) {
            return fewestFactorHeuristic(variables, factors);
        }
        return leastIncomingHeuristic(variables);
    }

    /**
     * This function computes how many factors contain the given variable and returns the result.
     * @param variable
     * @param factors
     * @return the number of factors in which the given variable is contained.
     */
    private Integer calculateAmountOfFactors(Variable variable, ArrayList<Factor> factors) {
        int result = 0;
        for(Factor f : factors){
            if(f.containsVar(variable)){
                result++;
            }
        }
        return result;
    }

    /**
     * This function determines the ordering of the variables based on the contained-in-fewest-factors heuristic.
     *
     * @param variables
     * @param factors
     * @return new ordering of variables.
     */
    private ArrayList<Variable> fewestFactorHeuristic(ArrayList<Variable> variables, ArrayList<Factor> factors) {
        Map<Variable, Integer> map = new HashMap<>();
        for (Variable var : variables) {
            // calculate the amount of factors the variable is in, and add it to the map together with the variable.
            map.put(var, calculateAmountOfFactors(var, factors));
        }
        // Create a new variable list and add the first variable to the list.
        ArrayList<Variable> order = new ArrayList<>();
        if(!variables.isEmpty()) {
            order.add(variables.get(0));
            for (int i = 1; i < variables.size(); i++) {
                Variable v = variables.get(i);
                // Add a variable that checks if the variable is already added to the list.
                boolean added = false;
                for (int j = 0; j < i; j++) {
                    // For every position in the newly created list, check whether the variable is in
                    // less factors than the variable at that position in the new list.
                    if (map.get(v) < map.get(order.get(j)) && !added) {
                        // If it is, add the variable to that position and move the rest one place up.
                        order.add(j, v);
                        // Set the boolean to true and continue with the function.
                        added = true;
                    }
                }
                // If the variable is compared to all other variables in the new list, but the amount of factors that it is
                // in is higher than that of the other variables, then add the variable to the end of the list.
                if (!added) {
                    order.add(v);
                }
            }
            // Return the new list with the correct ordering.
        }
        return order;
    }

    /**
     * This function determines the ordering of the variables based on the least-incoming-arcs heuristic.
     *
     * @param variables
     * @return new ordering of the variables.
     */
    private ArrayList<Variable> leastIncomingHeuristic(ArrayList<Variable> variables) {
        ArrayList<Variable> order = new ArrayList<>();
        if(!variables.isEmpty()) {
            // Create a new variable list and add the first variable to the list.
            order.add(variables.get(0));
            for (int i = 1; i < variables.size(); i++) {
                Variable var = variables.get(i);
                // Add a variable that checks whether the variable is already added to the list.
                boolean added = false;
                for (int j = 0; j < order.size(); j++) {
                    // For every position in the newly created list, check whether the variable has less parents
                    // than the variable at that position in the new list.
                    if (var.getNrOfParents() < order.get(j).getNrOfParents() && !added) {
                        // If it has less parents, add the variable to that position and move the variables with more parents
                        // one place up.
                        order.add(j, variables.get(i));
                        // Set the boolean to true and continue with the function.
                        added = true;
                    }
                }
                //If the variable is compared to all other variables in the new list, but the amount of parents that it has
                //is higher than that of the other variables, then add the variable to the end of the list.
                if (!added) {
                    order.add(var);
                }
            }
            // Return the new list with the correct ordering.
        }
        return order;
    }
}
