package varelim;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

/**
 * Class to represent a factor of a probability table on which computations can be performed.
 *
 * @author Simon Janssen and Jonathan Bauermeister
 * Extended by Merlijn van Elteren, Luuk Jacobs and Simon Janssen
 */

public class Factor extends Table{

    private ArrayList<Variable> vars = new ArrayList<>();

    /**
     * Constructor of the class.
     * @param v, variable belonging to the current probability table and factor.
     * @param table, table made out of probability rows (ProbRows).
     */
    public Factor(Variable v, ArrayList<ProbRow> table){
        super(v, table);
        vars.add(v);
        if(v.getNrOfParents() > 0) {
            vars.addAll(getParents());
        }
    }

    /**
     * Constructor of the class.
     * @param vars, variables that are in the factor.
     * @param var, variable belonging to the probability table and factor.
     */
    public Factor(ArrayList<Variable> vars, Variable var){
        this.vars = vars;
        setVariable(var);
    }

    /**
     * Constructor of the class.
     * @param original
     */
    public Factor(Factor original){
        super(original.getVariable(), original.getTableCopy());
        this.vars = new ArrayList<>(original.getVars());
    }

    /**
     * This function returns all variables that are contained in the factor.
     * @return all variables in the factor
     */
    public ArrayList<Variable> getVars(){
        return vars;
    }

    /**
     * @return the number of variables the factor contains.
     */
    public int NrOfVariables(){
        return vars.size();
    }

    /**
     * This function returns a boolean whether or not a given variable is contained in the factor
     * @param variable
     * @return boolean whether or not the variable is contained in the factor
     */
    public boolean containsVar(Variable variable){
        return vars.contains(variable);
    }

    /**
     * This function returns the position of the variable in the table (which column has the values of that variable).
     * @param v: The variable
     * @return position of variable in the table.
     */
    public int position(Variable v){
        return vars.indexOf(v);
    }

    /**
     * Returns a list of probability rows with the same assignment for a specified variable.
     * @param rows
     * @param assignment
     * @param position
     * @return list of assignments where the value assignment for the specified position is the same as in @param assignment.
     */
    public ArrayList<ProbRow> getSameAssignments(ArrayList<ProbRow> rows, ProbRow assignment, int position) {
        ArrayList<ProbRow> sameAssignments = new ArrayList<>();
        for (ProbRow row : rows) {
            if (assignment.isSame(row, position)) {
                sameAssignments.add(row);
            }
        }
        return sameAssignments;
    }

    /**
     * This function sums out a specified variable from the table and computes a new factor without that variable in it.
     *
     * @param v: the variable that needs to be summed out.
     * @return the new factor with the variable summed out.
     */
    public Factor marginalize(Variable v){
        // Make sure that the variable is indeed included in the factor
        if(!containsVar(v)){
            return null;
        }
        // Create new probability table.
        ArrayList<ProbRow> newTable = new ArrayList<>();
        // Make a duplicate of the table.
        ArrayList<ProbRow> rows = getTableCopy();
        // While there are still rows left, get the first assignment
        while(rows.size() > 0){
            ProbRow assignment = rows.remove(0);
            // Get rows with the same assignment, except for the variable that you want to marginalize out.
            ArrayList<ProbRow> sameAssignments = getSameAssignments(rows, assignment, position(v));
            // Calculate the total probability for rows with the same assignment.
            double prob = assignment.getProb();
            for(ProbRow ass : sameAssignments){
                prob += ass.getProb();
            }
            rows.removeAll(sameAssignments);
            // Make a new probability row with the variable and values marginalized out and with the new probability.
            ProbRow newA = new ProbRow(assignment.getValues(), prob);
            if(newA.getValues().size() > 1) {
                newA.remove(position(v));
            }
            newTable.add(newA);
        }
        // Remove the variable from the variable list and set the probability table to the new computed probability table.
        setTable(newTable);
        vars.remove(v);
        return this;
    }

    /**
     * This function maximizes over a specified variable in a factor and computes a new factor without the variable.
     *
     * @param v
     * @return the new factor with the variable maximized out.
     */
    public Factor maximize(Variable v){
        // Make sure that the variable is indeed included in the factor
        if(!containsVar(v)){
            return null;
        }
        // Create new probability table.
        ArrayList<ProbRow> newTable = new ArrayList<>();
        // Make a duplicate of the table.
        ArrayList<ProbRow> rows = getTableCopy();
        // While there are still rows left, get the first assignment
        while(rows.size() > 0){
            ProbRow assignment = rows.remove(0);
            // Get rows with the same assignment, except for the variable that you want to maximize.
            ArrayList<ProbRow> sameAssignments = getSameAssignments(rows, assignment, position(v));
            // Get the row with the maximum probability.
            ProbRow maxRow = assignment;
            for(ProbRow newRow : sameAssignments){
                if(maxRow.getProb() < newRow.getProb()){
                    maxRow = newRow;
                }
            }
            rows.removeAll(sameAssignments);
            // Make a new probability row with the variable and values marginalized out and with the new probability.
            if(maxRow.getValues().size() > 1) {
                maxRow.remove(position(v));
            }
            newTable.add(maxRow);
        }
        // Remove the variable from the variable list and set the probability table to the new computed probability table.
        setTable(newTable);
        vars.remove(v);
        return this;
    }

    /**
     * @return the value of a variable in the factor for which the probability is maximal.
     */
    public String argmax() {
        // Normalize the factor to get a probability distribution (for visualization purposes).
        this.normalize();
        // Create a map to extract the value
        HashMap<Double,String> dict = new HashMap<>();
        for(ProbRow row: this.getTable()){
            dict.put(row.getProb(), row.getValues().get(0));
        }
        // Locate the maximal probability.
        double maxProb = Collections.max(dict.keySet());
        // Return the value for which the probability is maximal.
        return dict.get(maxProb);
    }

    /**
     * This function computes the new factor when a factor is reduced by a given variable that takes on a given value.
     *
     * @param v: Variable that needs to be reduced.
     * @param value: value that the variable takes on.
     * @return new factor with the variable reduced to the specific value
     */
    public Factor reduce(Variable v, String value){
        // Make sure that the variable is indeed included in the factor
        if(!containsVar(v)){
            return null;
        }
        // Create new probability table.
        ArrayList<ProbRow> newTable = new ArrayList<>();
        // For every assignment in the table
        for(ProbRow assignment : getTable()){
            // If the value for the variable that you want to reduce equals the specified value
            if(assignment.getValues().get(position(v)).equals(value)){
                // Create a new probability row without that variable and with the same probability
                ProbRow newA = new ProbRow(assignment.getValues(), assignment.getProb());
                if(newA.getValues().size() > 1) {
                    newA.remove(position(v));
                }
                newTable.add(newA);
            }
        }
        // Remove the variable from the variable list and set the probability table to the new computed probability table.
        setTable(newTable);
        vars.remove(v);
        return this;
    }

    /**
     * This function computes the product of two specified factors.
     *
     * @param f: factor that gets multiplied.
     * @return new factor: result of multiplication of the two factors.
     */
    public Factor product(Factor f){
        // Create an arraylist for variables that are both in factor 1 and in factor 2.
        ArrayList<Variable> commonVars = new ArrayList<>();
        // Create an arraylist for all different variables that are either in factor 1 or in factor 2.
        // Create an arraylist that keeps track of the positions of the common variables in the tables for the second factor.
        ArrayList<Integer> positions = new ArrayList<>();
        // Add the variables of both factors to the appropriate lists.
        ArrayList<Variable> allVars = new ArrayList<>(vars);
        for(Variable v : f.getVars()){
            if(allVars.contains(v)){
                commonVars.add(v);
                positions.add(f.position(v));
            }
            else{
                allVars.add(v);
            }
        }
        Factor newF = new Factor(allVars, getVariable());
        ArrayList<ProbRow> newTable = new ArrayList<>();
        // For every row in the table of factor 1 and factor 2.
        for(ProbRow a1 : getTable()){
            for(ProbRow a2 : f.getTable()){
                boolean same = true;
                // Check that the common variables have the same assignment in both rows.
                if(commonVars.size() > 0) {
                    for (Variable common : commonVars) {
                        if (!a1.getValues().get(position(common)).equals(a2.getValues().get(f.position(common)))) {
                            same = false;
                        }
                    }
                }
                // Merge the variable assignments of the two assignments into 1 new single assignment and calculate that probability
                if(same) {
                    ProbRow newA = a1.merge(a2, positions);
                    newTable.add(newA);
                }
            }
        }
        // Update the probability table and return the factor.
        newF.setTable(newTable);
        return newF;
    }

    /**
     * This function normalizes the factor by making sure it is a probability distribution again. The total
     * probability of the table should sum to 1, so each probability in the table gets divided by the total
     * probability of the table.
     * @return normalized factor
     */
    public Factor normalize(){
        double sum = 0;
        // Calculate the total probability in the variable table
        for(ProbRow row: getTable()){
            sum += row.getProb();
        }
        // Normalize each probability from the table
        for(int i = 0; i < getTable().size(); i++){
            ProbRow row = getTable().get(i);
            row.setProb(row.getProb()/sum);
        }
        return this;
    }

    /**
     * This function makes a large string as a representation of the factor.
     * @return full string of variables in factor and probability table
     */
    public String toString() {
        StringBuilder tableString = new StringBuilder("f( ");
        for (int i = 0; i < vars.size(); i++) {
            if(i < vars.size() - 1) {
                tableString.append(vars.get(i).getName()).append(", ");
            }
            else{
                tableString.append(vars.get(i).getName()).append(" ");
            }
        }
        tableString.append(")");
        for(ProbRow row: getTable()) {
            tableString.append("\n").append(row.toString());
        }
        return tableString + "\n";
    }

    /**
     * This function makes a shorthand version of the factor into a string, in the form 'f(A,B,C)'
     * where A, B and C are variables
     * @return string of factor representation
     */
    public String shortString(){
        StringBuilder tableString = new StringBuilder("f( ");
        for (int i = 0; i < vars.size(); i++) {
            if(i == vars.size() - 1){
                tableString.append(vars.get(i).getName());
            }
            else {
                tableString.append(vars.get(i).getName()).append(", ");
            }
        }
        tableString.append(" )");
        return tableString.toString();
    }
}
